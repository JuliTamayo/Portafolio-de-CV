package com.example.lista_equipos_tamayoduran_silviajuliana;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class EquiposAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Equipos> equip;

    public EquiposAdapter(Context context, ArrayList<Equipos> equip) {
        this.context = context;
        this.equip = equip;
    }
    @Override
    public int getCount() {
        return equip.size();
    }

    @Override
    public Object getItem(int i) {
        return equip.get(i);
    }

    @Override
    public long getItemId(int i) {
        return equip.get(i).hashCode();
    }


    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view==null){
            view= LayoutInflater.from(context).inflate(R.layout.listar_equipos,null);
        }

        TextView nombre =view.findViewById(R.id.nombre);
        TextView codigo =view.findViewById(R.id.codigo);
        TextView serial =view.findViewById(R.id.serial);
        ImageView imageView= view.findViewById(R.id.imageView);

        Equipos e = equip.get(i);
        nombre.setText(e.getNom());
        codigo.setText(String.valueOf(e.getCod()));
        serial.setText(String.valueOf(e.getSer()));

        Picasso.get()
                .load(e.getImagen())
                .resize(250,250)
                .into(imageView);
        return view;
    }
}
