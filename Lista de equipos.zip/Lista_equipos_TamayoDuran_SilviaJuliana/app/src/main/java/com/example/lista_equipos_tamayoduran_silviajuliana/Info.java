package com.example.lista_equipos_tamayoduran_silviajuliana;

import java.util.ArrayList;

public class Info {

    public static final ArrayList<Equipos> EQUIPOS= new ArrayList<>();

    public static void Cargar(int n){
        for (int i=0; i<n;i++) {
            Equipos equi= new Equipos((1+i),"Soluciones Prontas",1203+(i*231));
            Info.EQUIPOS.add(equi);
        }
    }
}
