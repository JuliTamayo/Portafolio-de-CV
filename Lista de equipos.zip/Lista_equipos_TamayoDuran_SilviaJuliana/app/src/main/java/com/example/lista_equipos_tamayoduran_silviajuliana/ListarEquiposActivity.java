package com.example.lista_equipos_tamayoduran_silviajuliana;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

public class ListarEquiposActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_equipos);
        Mostrarlista();
    }
    private void Mostrarlista(){
        ListView lista= findViewById(R.id.lista);
        EquiposAdapter adapter= new EquiposAdapter(getApplicationContext(),Info.EQUIPOS);
        lista.setAdapter(adapter);

    }

    public void Volver(View view){
        finish();
    }
}