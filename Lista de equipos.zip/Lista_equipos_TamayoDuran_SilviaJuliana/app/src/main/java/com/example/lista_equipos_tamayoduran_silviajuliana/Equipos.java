package com.example.lista_equipos_tamayoduran_silviajuliana;

public class Equipos {

    private long cod;
    private String nom;
    private long ser;
    private String imagen="https://www.labclin2019.es/images/images/site/ponentes/nofotog.png";

    public Equipos(long cod, String nom, long ser) {
        this.cod = cod;
        this.nom = nom;
        this.ser = ser;
    }

    public long getCod() {
        return cod;
    }

    public void setCod(long cod) {
        this.cod = cod;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public long getSer() {
        return ser;
    }

    public void setSer(long ser) {
        this.ser = ser;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    @Override
    public String toString() {
        return "Equipos{" +
                "cod=" + cod +
                ", nom='" + nom + '\'' +
                ", ser=" + ser +
                ", imagen='" + imagen + '\'' +
                '}';
    }
}
